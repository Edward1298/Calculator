import express from 'express';
import { Calculate } from '../Logic/Calculate.mjs'; 
import {Validations} from '../Logic/Validations.mjs'; 

const PORT = process.env.PORT ?? 8080
// Crear una instancia de Express
const app = express();
app.use(express.json());
try {
    
    app.get('/calculate', (req, res) =>
    {
        const startTime = Date.now();

        let { a, b, operator } = req.query;
        if (!a || !b || !operator) { 
            const duration = Date.now() - startTime;  
            return res.json({
                error:'Missing parameters: a, b, and operator are required.',  
                timestamp: duration   
            });
    
        }
        const num1 = parseFloat(a);
        const num2 = parseFloat(b);
        
        
        let validations = Validations(num1, num2, operator)
        
        
        if(validations === 'ok')
        {
            if (operator === ' ') {
                operator = '+';
            }
            const result = Calculate(parseFloat(a), parseFloat(b), operator);
            const duration = Date.now() - startTime;
            return res.json({
                operation: operator,  // Operation performed
                input: {
                    num1: parseFloat(a),
                    num2: parseFloat(b)
                },  // Input values
                result: result,  
                timestamp: duration// Result of the operation
                
            });
        } else { 
            const duration = Date.now() - startTime;
            return res.json({
                error: validations, // Validation error message
                timestamp: duration  
            });
        }
    
        })

    } 
    catch(err)
    {
        console.error(err.message);
        res.status(500).json({ message: 'Internal Server Error' });
    }

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`El servidor está escuchando en el puerto http://localhost:${PORT}`);
  });