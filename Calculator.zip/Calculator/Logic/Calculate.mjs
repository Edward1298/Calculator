
// Logic/Calculate.mjs

export function Calculate(a, b, operator) {
    switch (operator) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            if (b === 0) {
                return 'Cannot divide by zero.';
            }
            return a / b;
        default:
            return 'Invalid operator. Supported operators are +, -, *, /.';
    }
}
