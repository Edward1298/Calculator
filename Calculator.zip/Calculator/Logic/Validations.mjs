export function Validations(a, b, operator)
{
     if (isNaN(a) || isNaN(b)) {

        return 'Both a and b must be valid numbers.';
      } else{
        return "ok"
      }

}